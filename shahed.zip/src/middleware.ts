export { middleware } from "@/lib/auth/middleware";

export const config = {
  matcher: ["/dashboard/:path*"],
};
