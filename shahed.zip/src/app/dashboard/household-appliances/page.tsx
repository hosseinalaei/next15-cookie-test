const HouseAppPage = () => {
  return (
    <>
      <p>HouseAppPage</p>
    </>
  );
};

export default HouseAppPage;
