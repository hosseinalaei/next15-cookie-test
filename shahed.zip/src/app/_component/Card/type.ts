type CardProps = {
  className?: string;
  icon?: string;
  title?: string;
  value?: string;
  children: React.ReactNode;
};
