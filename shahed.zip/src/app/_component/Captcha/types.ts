type Captcha = {
  getCaptcha: () => void;
  captcha: string;
  setInsertCaptcha?: any;
};
