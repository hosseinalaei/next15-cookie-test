export const cookieName = "USER_SESSION";
